# Alfred — osobní chat

Jednoduchá chatovací aplikace ve stylu Jarvise. Běží celá u tebe v prohlížeči, bez instalace a bez placených služeb.

Jsi Alfred, osobní asistent Jakuba. Odpovídá česky a tyká.

**Výchozí mozek je Groq** (bezplatný plán, bez platební karty). V Nastavení můžeš přepnout na Google Gemini jako záložní bezplatnou možnost.

## Jak aplikaci spustit

1. Pro rychlý test stačí otevřít soubor `index.html` v prohlížeči — dvakrát na něj klikni (Chrome, Edge, Firefox i Safari). Přes `file://` ale **nejde aplikaci nainstalovat** a oprávnění k mikrofonu se může ptát znovu při každém načtení.
2. Žádný build není potřeba. Pro instalaci jako aplikace (PWA) ji spusť přes `https` (třeba GitHub Pages) nebo místně na `http://localhost` — viz níže.
3. K chatu i ke stažení písem z Google Fonts potřebuješ internet.

## Jak získat bezplatný Groq klíč (doporučeno, bez karty)

1. Jdi na [https://console.groq.com](https://console.groq.com).
2. Klikni na **Sign up** a zaregistruj se přes Google, GitHub, nebo e-mail. **Platební kartu nevyplňuj** — bezplatný plán (Free) kartu nevyžaduje. Karta je potřeba až při případném přechodu na placený plán Developer.
3. Po přihlášení otevři stránku s klíči: [https://console.groq.com/keys](https://console.groq.com/keys) (nebo v levém menu položku **API Keys**).
4. Klikni na **Create API Key**, klíč pojmenuj (třeba „Alfred“) a zkopíruj ho. Ukáže se jen jednou.
5. Klíč vlož jedním z těchto dvou způsobů:

### Varianta A — panel Nastavení (doporučeno)

1. V aplikaci klikni vpravo nahoře na ikonu ozubeného kola.
2. Nech poskytovatele **Groq**.
3. Do pole **Groq API klíč** vlož klíč a stiskni **Uložit**.
4. Klíč se uloží jen do `localStorage` tohoto prohlížeče. Nikam jinam se neposílá, kromě volání Groq API.

### Varianta B — konstanta v souboru

V souboru `index.html` na **řádku 868** je:

```js
const GROQ_API_KEY = 'SEM_VLOZ_SVUJ_GROQ_KLIC';
```

Nahraď text `SEM_VLOZ_SVUJ_GROQ_KLIC` svým klíčem a soubor ulož. Tuto variantu použij, jen když soubor nikomu nepřeposíláš a **nedáváš ho do veřejného repozitáře** — klíč by v něm byl uložený jako čitelný text.

Když je klíč vyplněný v Nastavení, má přednost před konstantou.

## Groq: modely a limity

Výchozí pořadí modelů (při chybě 429/503 nebo nedostupnosti se automaticky zkusí další):

1. `openai/gpt-oss-120b` — produkční model, silný v desítkách jazyků včetně češtiny
2. `qwen/qwen3.8-27b` — náhradní (v dokumentaci Groq je jako preview)
3. `openai/gpt-oss-20b` — menší, rychlejší produkční model

Pořadí můžeš upravit v Nastavení (jeden identifikátor na řádek). U odpovědi je vždy vidět, který model odpověděl.

Aplikace volá přímo OpenAI-kompatibilní rozhraní:

`https://api.groq.com/openai/v1/chat/completions`

Funguje i po otevření souboru přes `file://` — Groq API to z prohlížeče povoluje.

Podle oficiální tabulky [rate limits](https://console.groq.com/docs/rate-limits) mají tyto textové modely typicky **30 požadavků za minutu** a **1 000 za den**, plus limity tokenů (8 000 za minutu a 200 000 za den). Přesná čísla pro tvůj účet jsou v konzoli Groq. Limity platí pro celou organizaci, ne pro jednotlivý klíč. Když aplikace napíše, že požadavek byl odmítnut kvůli limitu, počkej chvíli, nebo nech aplikaci zkusit další model v seznamu.

Zůstaň na plánu **Free**. Přechod na Developer vyžaduje platební metodu a už není zdarma.

## Záložní poskytovatel: Google Gemini

V Nastavení můžeš přepnout poskytovatele na **Google Gemini**.

1. Bezplatný klíč získej na [https://aistudio.google.com/apikey](https://aistudio.google.com/apikey) (účet Google, zdarma).
2. Vlož ho do pole **Gemini API klíč**, nebo do konstanty `GEMINI_API_KEY` na **řádku 869** v `index.html` (placeholder `SEM_VLOZ_SVUJ_KLIC`).
3. Gemini používá [Interactions API](https://ai.google.dev/gemini-api/docs/interactions-overview) (`POST https://generativelanguage.googleapis.com/v1beta/interactions`). Modely Gemma jdou přes starší `generateContent`.
4. Výchozí pořadí modelů pro nové účty: `gemini-3.5-flash-lite`, `gemini-4-hydrogen`, `gemini-3.1-flash-lite`, `gemini-3.6-flash`, `gemini-3.8-flash`, `gemma-4-31b-it`, `gemma-4-26b-a4b-it`.
5. `gemini-3.8-flash` je oficiálně zdarma, ale bývá přetížený. Modely řady 2.5 už pro nové uživatele často nejsou dostupné, proto ve výchozím seznamu nejsou.
6. Na bezplatné úrovni má Gemini denní a minutové limity (čísla se mění, viz [dokumentace](https://ai.google.dev/gemini-api/docs/rate-limits)) a Google může použít obsah ke zlepšování produktů.

## Hlasové zadávání

Vedle pole pro zprávu je tlačítko mikrofonu. Po kliknutí prohlížeč začne poslouchat česky (`cs-CZ`) a text se postupně zapisuje do vstupního pole. Zprávu odešleš sám Enterem nebo tlačítkem odeslání — mikrofon nic neodesílá automaticky. Dalším kliknutím na mikrofon, odesláním zprávy, nebo spuštěním čtení odpovědi se poslech zastaví.

Funguje v **Chrome** a **Edge** (Web Speech API). V jiných prohlížečích je tlačítko vypnuté. Chrome k rozpoznávání potřebuje internet.

Oprávnění k mikrofonu si prohlížeč pamatuje **podle původu (origin)**. Když Alfred běží přes `https` nebo `http://localhost` (včetně nainstalované aplikace), stačí mikrofon povolit jednou. Přes `file://` (dvojklik na `index.html`) ho může žádat znovu při každém načtení a aplikaci odtud nainstalovat nejde.

Místní server na počítači:

```bash
cd alfred-chat
python3 -m http.server 8000
```

Pak otevři [http://localhost:8000](http://localhost:8000). Tento způsob je jen pro desktop, ne pro telefon.

Když v Nastavení vyplníš hlasový server, mikrofon místo toho nahrává zvuk a posílá ho na server (viz níže). Text v poli se při tom samo nevyplňuje — přepis i odpověď přijdou přímo do chatu.


## Instalace jako aplikace a zveřejnění

Alfred je teď instalovatelná webová aplikace (PWA). Ikona, celoobrazovkový režim a service worker fungují jen tehdy, když stránku otevřeš přes **https** nebo **localhost**. Přes `file://` se nainstalovat nedá.

### Zdarma na GitHub Pages

1. Na GitHubu založ **nový veřejný repozitář** (třeba `alfred`).
2. Nahraj do kořene repozitáře soubory aplikace: `index.html`, `README.md`, `manifest.webmanifest`, `sw.js` a složku `icons/`. Nepoužívej vnořenou složku, jinak se cesty k ikonám a manifestu rozbijí.
3. **Důrazně varování:** API klíč nech jen v Nastavení aplikace. Ukládá se výhradně do `localStorage` tvého prohlížeče a na GitHub se neodesílá. **Do veřejného repozitáře klíč nikdy nevkládej** — v `index.html` nech placeholdery `SEM_VLOZ_SVUJ_GROQ_KLIC` a `SEM_VLOZ_SVUJ_KLIC`. Kdybys klíč vepsal do konstanty a soubor zveřejnil, kdokoli ho může zkopírovat a vyčerpat ti limit.
4. V repozitáři otevři **Settings → Pages**. U **Source** zvol **Deploy from a branch**, větev **main** (nebo `master`) a složku **/ (root)**. Ulož.
5. Za chvíli bude aplikace na adrese `https://<uživatel>.github.io/<repozitář>/` — například `https://jakub.github.io/alfred/`. Přesný název účtu a repozitáře dosaď podle sebe.
6. Tuto adresu otevři v prohlížeči, v Nastavení vlož klíč a případně aplikaci nainstaluj.

### Místně na počítači (jen desktop)

```bash
cd alfred-chat
python3 -m http.server 8000
```

Otevři [http://localhost:8000](http://localhost:8000). Na telefonu tohle samo o sobě nestačí — pro instalaci na mobilu použij GitHub Pages nebo jiný `https` hosting.

### Jak aplikaci nainstalovat

Přesné názvy položek v menu se můžou v různých verzích prohlížeče mírně lišit. Když stránka instalaci nabízí, v záhlaví Alfreda se může objevit tlačítko **Nainstalovat**.

- **Chrome (počítač):** v adresním řádku někdy bývá ikona instalace. Jinak v nabídce (tři tečky) obvykle **Cast, save and share → Install page as app** (v češtině podobně jako *Odeslat, uložit a sdílet → Nainstalovat stránku jako aplikaci*).
- **Edge (počítač):** v nabídce typicky **Apps → Install this site as an app**, případně **Settings and more → More tools → Apps → Install this site as an app** (v češtině často *Aplikace → Nainstalovat tento web jako aplikaci*).
- **Chrome na Androidu:** v nabídce hledej **Install app**, **Add to Home screen**, nebo v novějších verzích **Install and create shortcut** a pak **Install**.
- **iPhone (Safari):** **Sdílet → Add to Home Screen** (*Přidat na plochu*). V novějším iOS může být ještě volba *Open as Web App* / *Otevřít jako webovou aplikaci* — nech ji zapnutou, pokud ji vidíš. Na iPhone je hlasové **rozpoznávání** (mikrofon přes Web Speech API) omezené nebo nedostupné; čtení odpovědí nahlas obvykle funguje.


## Hlasový server (Microsoft hlas, Whisper)

Volitelně můžeš Alfreda napojit na bezplatný hlasový server ze složky `alfred-voice-server`. Ten umí přepsat nahrávku (Groq Whisper), nechat Alfreda odpovědět a vrátit mluvené MP3 hlasem Microsoft Edge (`cs-CZ-AntoninNeural`). Podrobný postup nasazení (místně i zdarma na Renderu) je v `README.md` u toho serveru — tady stačí zkráceně:

1. Nasaď server podle jeho README a zkopíruj jeho adresu (třeba `https://alfred-voice.onrender.com`) a tajný `ALFRED_TOKEN`.
2. V chatu otevři **Nastavení → Hlasový server**, vlož adresu (bez koncového lomítka) a token a stiskni **Uložit**.
3. Tlačítkem **Otestovat spojení** ověř `GET /health`. Token se k tomuto požadavku nevyžaduje. Když služba na Renderu spí, první odpověď může trvat **až minutu** — to není chyba, počkej a případně zkus znovu.
4. Když jsou adresa i token vyplněné:
   - mikrofon nahraje hlas přes `MediaRecorder` a po vypnutí ho pošle na `POST /api/voice` (s nedávnou historií chatu). Přepis se uloží jako tvoje zpráva, odpověď jako zpráva Alfreda a přehraje se vrácené MP3;
   - napsanou zprávu pořád zpracuje Groq (nebo Gemini) přímo z prohlížeče, včetně streamování textu. Čtení jde po větách na `POST /api/tts`, aby hrál Microsoft hlas. Když server TTS selže, ta odpověď se jednou přepne na hlas prohlížeče a ukáže se krátká hláška.
5. Když adresu nebo token necháš prázdné, chová se aplikace jako dřív: Web Speech API v prohlížeči a `speechSynthesis`.
6. Ztlumení zastaví přehrávání MP3 (odpověď v chatu zůstane). Nové nahrávání ani odeslání zprávy nespustíš souběžně s přehráváním — přehrávání se nejdřív zruší. Service worker hlasový server neukládá do mezipaměti.

## Hlasové čtení odpovědí

Po každé odpovědi Alfred přečte text nahlas přes `window.speechSynthesis`. Použije český hlas (preferuje se `lang` začínající na `cs`), a když se hlasy načtou později, aplikace to zachytí událostí `voiceschanged`. Když český hlas není, nastaví alespoň jazyk výslovnosti `cs-CZ`. Hlas se vybere jednou na začátku čtení.

U Groq se odpověď stahuje proudem (`stream: true`). Text se v bublině doplňuje průběžně a jakmile skončí první věta, Alfred ji začne číst — nemusíš čekat na celou odpověď. Když stream selže, aplikace stejný model zkusí bez streamu. Gemini zůstává bez streamu a čte se hned po příchodu celé odpovědi.

Alfred je v systémovém pokynu vedený k tomu, aby odpovídal jako v živém hovoru: stručně, přirozeně, tykáním, obvykle jednou až třemi plynulými větami, bez Markdownu, seznamů, nadpisů a emoji.

Před čtením se z textu odstraní Markdown, bloky kódu, odkazy a štítek „který model odpověděl“. Krátké věty se slučují do úseků přibližně 120–200 znaků (na hranicích vět nebo čárek), aby mezi nimi nebyly zbytečné mezery. Delší úseky se dál dělí, protože Chrome je po zhruba 15 sekundách ořízne. Výchozí tempo čtení je 1,05 a v Nastavení ho můžeš upravit posuvníkem.

Tlačítko reproduktoru v záhlaví hlas ztlumí nebo zapne. Stav se ukládá do `localStorage` a výchozí je **zapnuto**. Čtení včetně fronty streamovaných vět se okamžitě zruší, když ztlumíš hlas, spustíš mikrofon, nebo odešleš novou zprávu. Dokud Alfred mluví, mikrofon neposlouchá, aby neslyšel sám sebe.

Když v prohlížeči není žádný český hlas, jednou se ukáže nápověda, že v Edge bývají hlasy Microsoft Antonín nebo Vlasta Online. Konkrétní hlas můžeš vybrat v Nastavení.

## Co aplikace umí

- Historie chatu se pamatuje v prohlížeči. Tlačítko koše nahoře historii smaže.
- Enter odešle zprávu, Shift+Enter udělá nový řádek.
- Odpovědi se vykreslují s jednoduchým Markdownem (tučné písmo, seznamy, odkazy, kód).
- Při přetížení nebo limitu se stejný model jednou znovu zkusí s krátkou pauzou a potom se přepne na další v seznamu.
- Hlasové zadávání mikrofonem (Chrome/Edge, čeština) a hlasité čtení odpovědí, u Groq už od první věty.

## Soukromí

Klíč a historie chatu zůstávají u tebe v prohlížeči (nebo v `index.html`, pokud klíč vložíš do konstanty). Odchozí volání jdou na zvoleného poskytovatele (Groq nebo Google Gemini) a, když je zapnutý, na tvůj hlasový server (ten dál volá Groq a hlasy Microsoftu). Do chatu ani do hovoru nedávej hesla, čísla karet ani jiné citlivé údaje.
