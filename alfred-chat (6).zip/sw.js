"use strict";

var CACHE_NAME = "alfred-shell-v2";
var SHELL_PATHS = [
  "./",
  "index.html",
  "manifest.webmanifest",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "icons/icon-512-maskable.png",
  "icons/apple-touch-icon.png",
  "icons/icon.svg"
];

function shellUrls() {
  return SHELL_PATHS.map(function (path) {
    return new URL(path, self.registration.scope).href;
  });
}

function isApiOrVoice(url) {
  var host = String(url.hostname || "").toLowerCase();
  if (host === "api.groq.com" || host.indexOf(".groq.com") !== -1) return true;
  if (host === "generativelanguage.googleapis.com") return true;
  if (host.indexOf("generativelanguage") !== -1) return true;
  if (/voice/.test(host)) return true;
  if (/\/(?:api\/)?(?:voice|stt|tts|asr|speech)(?:\/|$|\?)/i.test(url.pathname)) return true;
  return false;
}

function isAppDocument(request, url) {
  if (request.mode === "navigate" || request.destination === "document") return true;
  var scopePath = new URL(self.registration.scope).pathname;
  var path = url.pathname;
  if (path === scopePath) return true;
  if (path === scopePath.replace(/\/$/, "")) return true;
  if (path === scopePath + "index.html") return true;
  return false;
}

function isShellAsset(url) {
  if (url.origin !== self.location.origin) return false;
  var path = url.pathname;
  var scopePath = new URL(self.registration.scope).pathname;
  var rest = path.slice(scopePath.length);
  if (rest.charAt(0) === "/") rest = rest.slice(1);
  return SHELL_PATHS.indexOf(rest) !== -1 || SHELL_PATHS.indexOf("./" + rest) !== -1;
}

function networkFirst(request) {
  return fetch(request).then(function (response) {
    if (response && response.ok) {
      var copy = response.clone();
      caches.open(CACHE_NAME).then(function (cache) {
        cache.put(request, copy);
      }).catch(function () {});
    }
    return response;
  }).catch(function () {
    return caches.match(request).then(function (cached) {
      if (cached) return cached;
      return caches.match(new URL("index.html", self.registration.scope).href);
    });
  });
}

function cacheFirst(request) {
  return caches.match(request).then(function (cached) {
    if (cached) return cached;
    return fetch(request).then(function (response) {
      if (response && response.ok) {
        var copy = response.clone();
        caches.open(CACHE_NAME).then(function (cache) {
          cache.put(request, copy);
        }).catch(function () {});
      }
      return response;
    });
  });
}

self.addEventListener("install", function (event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function (cache) {
      return cache.addAll(shellUrls());
    }).then(function () {
      return self.skipWaiting();
    })
  );
});

self.addEventListener("activate", function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (key) {
        return key !== CACHE_NAME;
      }).map(function (key) {
        return caches.delete(key);
      }));
    }).then(function () {
      return self.clients.claim();
    })
  );
});

self.addEventListener("fetch", function (event) {
  var request = event.request;
  if (request.method !== "GET") return;
  var url;
  try {
    url = new URL(request.url);
  } catch (e) {
    return;
  }
  // Never cache API, TTS, or any cross-origin / voice-server traffic.
  if (url.origin !== self.location.origin) return;
  if (/\/api\//.test(url.pathname) || /\/health\/?$/.test(url.pathname)) return;
  if (isApiOrVoice(url)) return;
  if (isAppDocument(request, url)) {
    event.respondWith(networkFirst(request));
    return;
  }
  if (isShellAsset(url)) {
    event.respondWith(cacheFirst(request));
  }
});
