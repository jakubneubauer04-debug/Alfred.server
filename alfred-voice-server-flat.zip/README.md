# Alfred — bezplatný hlasový server

Malý server, který z prohlížeče umí vést plnohodnotný hlasový rozhovor: nahraje se mikrofon, server řeč přepíše, Alfred odpoví a vrátí mluvené MP3.

Celé je to zdarma. Žádná placená služba, žádné předplatné. Klíč Groq si založíš bez karty a Render zdarma kartu také nevyžaduje.

## Co server dělá

1. **Rozpoznání řeči (STT):** Groq Whisper, model `whisper-large-v3-turbo` (ověřeno v dokumentaci Groq v listopadu 2026). Jazyk je čeština (`cs`).
2. **Odpověď (LLM):** Groq Chat Completions, hlavní model `openai/gpt-oss-120b`, při výpadku `openai/gpt-oss-20b`. Alfred tyká, mluví česky, stručně a bez Markdownu. Historii konverzace posílá klient.
3. **Hlas (TTS):** knihovna `edge-tts` a bezplatné neurální hlasy Microsoft Edge. Výchozí je `cs-CZ-AntoninNeural`, alternativou `cs-CZ-VlastaNeural`. Vrací se `audio/mpeg`. Ověřeno spuštěním na vývojovém počítači: české MP3 se opravdu vygenerovalo. Jde o neoficiální využití veřejných hlasů Microsoftu, takže to jednou může přestat fungovat.

Klíč Groq se nikdy neukládá do kódu. Patří jen do proměnné prostředí `GROQ_API_KEY`.

## Soubory

| Soubor | Účel |
| --- | --- |
| `main.py` | FastAPI server |
| `requirements.txt` | Závislosti Pythonu |
| `render.yaml` | Blueprint pro bezplatnou službu na Renderu |
| `client-snippet.js` | Připravené napojení pro webovou stránku |
| `voice.html` | Samostatná ukázka (tmavý vzhled, česky) |
| `.env.example` | Vzor proměnných prostředí |
| `.python-version` | Python 3.13.5 |

Složku `/workspace/alfred-chat/` (soubor `index.html`) tento projekt **neupravuje**. Napojení do chatu je popsané níže a provedeš ho až později ručně.

## Místní spuštění

Na počítači s Pythonem 3.11 nebo novějším:

```bash
cd alfred-voice-server
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export GROQ_API_KEY="tvůj-klíč-z-groq"   # Windows: set GROQ_API_KEY=...
export ALFRED_TOKEN="libovolne-tajne-heslo"
uvicorn main:app --host 0.0.0.0 --port 8000
```

Klíč Groq získáš zdarma na [console.groq.com/keys](https://console.groq.com/keys). Založíš účet přes Google, GitHub nebo e-mail. Platební kartu vyplňovat nemusíš.

Pak v prohlížeči otevři:

- kontrolu: [http://127.0.0.1:8000/health](http://127.0.0.1:8000/health)
- ukázku: soubor `voice.html` (do pole adresy zadej `http://127.0.0.1:8000` a svůj token)

### Rozhraní

- `GET /health` — stav služby, token se nevyžaduje (kvůli kontrole na Renderu).
- `POST /api/voice` — nahrávka z mikrofonu (multipart pole `audio`, typicky `audio/webm;codecs=opus`) a volitelně `voice` a `history` (JSON pole zpráv). Odpověď je JSON: `transcript`, `reply`, `audio` (MP3 v base64), `audio_content_type`, `voice`, `model`.
- `POST /api/chat` — JSON `{ "text": "...", "history": [...], "voice": "..." }`. Vrátí text i MP3.
- `POST /api/tts` — JSON `{ "text": "...", "voice": "..." }`. Vrátí přímo `audio/mpeg`.

Když je nastavený `ALFRED_TOKEN`, všechny `/api/*` požadují hlavičku `X-Alfred-Token` (nebo `Authorization: Bearer ...`). Tím se cizí lidé nedostanou k tvému limitu Groq.

`ALLOWED_ORIGINS` je volitelný. Když zůstane prázdný, server povolí všechny origin, včetně `null` ze stránky otevřené jako `file://`.

## Nasazení na Render zdarma

Ověřeno z oficiální dokumentace Renderu (listopad 2026):

- Stránky [Deploy for Free](https://render.com/docs/free) a [Your First Render Deploy](https://render.com/docs/your-first-deploy) uvádějí bezplatné webové služby. Druhá z nich píše výslovně, že platba není potřeba.
- K založení účtu a spuštění bezplatné webové služby **není potřeba platební karta**.
- Bezplatná instance má 0,1 CPU a 512 MB RAM. Po **15 minutách bez příchozího provozu usne**. První další požadavek ji budí zhruba **až minutu**.
- Každý workspace má 750 bezplatných hodin měsíčně (usnutá služba hodiny nečerpá). Po vyčerpání se služba do začátku dalšího měsíce pozastaví.
- Když vyčerpáš bezplatný přenos dat nebo minuty sestavení a nemáš přidanou platbu, Render službu do konce měsíce může pozastavit. Pro běžné domácí použití to stačí.

Railway není potřeba. Render na to stačí a je zdarma.

### 1. GitHub a nahrání složky

1. Vytvoř si účet na [github.com](https://github.com/signup), pokud ho ještě nemáš.
2. Klikni na **New repository**, pojmenuj ho třeba `alfred-voice-server`. Může být soukromý i veřejný. **Nezaškrtávej** přidání README, Render si bere soubory, které nahraješ.
3. Na počítači ve složce projektu:

```bash
cd alfred-voice-server
git init
git add .
git commit -m "Alfred voice server"
git branch -M main
git remote add origin https://github.com/TVE_JMENO/alfred-voice-server.git
git push -u origin main
```

Na Windows můžeš místo příkazového řádku použít [GitHub Desktop](https://desktop.github.com/). Důležité je, aby v kořeni repozitáře ležely `main.py`, `requirements.txt` a `render.yaml`.

### 2. Účet na Renderu

1. Otevři [render.com](https://render.com/) a klikni na **Get Started** nebo **Sign up**.
2. Přihlas se přes GitHub (nejpohodlnější) nebo e-mail. Kartu nevyplňuj.
3. Pokud Render chce propojit GitHub, povol přístup k repozitáři `alfred-voice-server`.

### 3. Vytvoření služby

Jdou dvě cesty, vyber jednu.

**A) Blueprint z `render.yaml` (doporučeno)**

1. V dashboardu klikni na **New > Blueprint**.
2. Připoj repozitář `alfred-voice-server`.
3. Render načte `render.yaml` a nabídne službu `alfred-voice` na tarifu **Free**.
4. U proměnných s `sync: false` doplň hodnoty:
   - `GROQ_API_KEY` — klíč z [console.groq.com/keys](https://console.groq.com/keys)
   - `ALFRED_TOKEN` — vymysli si tajné heslo (třeba dlouhou náhodnou větu). Stejné pak vložíš do stránky.
   - `ALLOWED_ORIGINS` můžeš nechat prázdné
5. Spusť nasazení.

**B) Ručně jako Web Service**

1. **New > Web Service**, vyber stejný repozitář.
2. Nastavení:
   - **Language / Runtime:** Python
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`
   - **Instance / Compute plan:** **Free**
   - **Health Check Path:** `/health`
3. V Environment doplň `GROQ_API_KEY` a `ALFRED_TOKEN`.
4. Klikni na **Deploy**.

### 4. Adresa služby

Po úspěšném nasazení Render ukáže adresu ve tvaru:

```text
https://alfred-voice.onrender.com
```

Jméno v adrese se může lišit, pokud už `alfred-voice` někdo v regionu používá. Zkopíruj přesnou adresu z dashboardu.

Ověření: v prohlížeči otevři `https://TVA-ADRESA.onrender.com/health`. Mělo by přijít JSON s `"ok": true`. Když služba spí, počkej až minutu a obnov stránku.

Tuto adresu a token pak vlož do `voice.html` (nebo později do nastavení Alfredova chatu).

## Napojení na `index.html`

Soubor chatu teď neupravuj, pokud ho mění někdo jiný. Až budeš chtít napojení doplnit, postupuj takto. Všechny úpravy jsou v jednom souboru `index.html`.

1. **Přidej skript.** Těsně před uzavírací `</body>` (vedle stávajícího JavaScriptu, nebo nad ním) vlož:

   ```html
   <script src="client-snippet.js"></script>
   ```

   Soubor `client-snippet.js` musí ležet ve stejné složce jako `index.html`. Případně celý obsah `client-snippet.js` vlož do existujícího `<script>` jako knihovnu `AlfredVoice`.

2. **Přidej do Nastavení dvě pole** (vedle Groq klíče), například:

   ```html
   <label for="voiceServerUrl">Hlasový server (volitelné)</label>
   <input id="voiceServerUrl" placeholder="https://alfred-voice.onrender.com" autocomplete="off" spellcheck="false">
   <div class="help">Když je vyplněný, mikrofon posílá zvuk na tento server a Alfred odpovídá jeho hlasem. Jinak zůstane stávající rozpoznávání v prohlížeči.</div>
   <label for="alfredToken">Token hlasového serveru</label>
   <input id="alfredToken" type="password" placeholder="stejný jako ALFRED_TOKEN" autocomplete="off" spellcheck="false">
   ```

3. **Ulož je do stávajícího objektu nastavení**, stejně jako se ukládá `groqApiKey`. Přidej klíče `voiceServerUrl` a `alfredToken`, při otevření a uložení modalu je čti a zapisuj.

4. **Vytvoř klienta** po načtení stránky:

   ```javascript
   var voiceClient = AlfredVoice.create({
     serverUrl: state.settings.voiceServerUrl || "",
     token: state.settings.alfredToken || "",
     voice: "cs-CZ-AntoninNeural"
   });
   ```

   Při uložení nastavení zavolej `voiceClient.configure({ serverUrl: ..., token: ... })`.

5. **U mikrofonu přepni nahrávání.** Když je vyplněná adresa serveru, nepoužívej `SpeechRecognition`. Místo toho:

   - při kliknutí na mikrofon: `await voiceClient.startRecording()`
   - při druhém kliknutí (nebo puštění tlačítka):

   ```javascript
   var result = await voiceClient.stopAndSend(history);
   // result.transcript  — co Jakub řekl, ukaž jako uživatelskou zprávu
   // result.reply       — odpověď Alfreda, ukaž jako zprávu asistenta
   await voiceClient.play(result.audioBlob); // místo speechSynthesis
   ```

   `history` sestav ze stávajících zpráv chatu jako pole `{ role, content }`.

6. **Ponech zálohu.** Když adresa serveru není vyplněná, nebo volání selže, nech původní cestu: Web Speech API + Groq/Gemini + `speechSynthesis`. Klíč Groq v prohlížeči tím pádem zůstává jen jako záloha. Při zapnutém hlasovém serveru už klíč v prohlížeči není potřeba, protože ho má server.

7. **Ověř CORS.** Stránka otevřená z disku (`file://`) posílá origin `null`. Server to umí. Po nasazení na Render nejdřív zkus `voice.html` a teprve potom úpravy v `index.html`.

Hotovou ukázku tohoto toku máš v `voice.html`: tlačítko umí stisknout a držet i přepínat, zobrazí přepis i odpověď a přehraje MP3.

## Na co pamatovat

- **Render usíná.** Po zhruba 15 minutách ticha trvá první požadavek až minutu. To není chyba aplikace. V ukázce tlačítko „Ověřit server“ službu probudí.
- **Limity Groq.** Bezplatná úroveň má strop na počet požadavků za minutu a za den. Když padne chyba 429, počkej a zkus to znovu. Aktuální limity jsou v [console.groq.com](https://console.groq.com/).
- **edge-tts je neoficiální.** Používá veřejné hlasy Microsoft Edge. Microsoft to může kdykoli omezit. Server v takovém případě vrátí srozumitelnou chybu, chat jinak nespadne.
- **Žádné tajemství do Gitu.** Do repozitáře nepatří soubor `.env` ani skutečný klíč. Token i klíč zadávej jen v nastavení Renderu.
- **Citlivé údaje.** Do hovoru neříkej hesla, čísla karet ani jiné tajné informace. Zvuk jde na Groq (přepis a odpověď) a k Microsoftu (čtení hlasem).
- **Prohlížeč.** Nahrávání z mikrofonu funguje v Chromu a v Edge. Soubor otevřený z disku se může na mikrofon ptát opakovaně; to je chování prohlížeče.

## Licence a autorská práva

Kód serveru je určený pro osobní použití Jakuba. Hlasy patří Microsoftu a používají se přes veřejné rozhraní edge-tts. Modely patří jejich poskytovatelům (Groq / OpenAI / Whisper).
