/**
 * Alfred — napojení webové stránky na hlasový server.
 *
 * Tento soubor NEPŘIDÁVEJ automaticky do /workspace/alfred-chat/index.html.
 * index.html právě upravuje jiný pracovní postup. Až bude hotový, zkopíruj
 * potřebné části ručně podle README.md, sekce „Napojení na index.html".
 *
 * Použití (samostatně i uvnitř Alfredova chatu):
 *
 *   const client = AlfredVoice.create({
 *     serverUrl: "https://alfred-voice.onrender.com",
 *     token: "tajny-token",          // stejný jako ALFRED_TOKEN, může být prázdný
 *     voice: "cs-CZ-AntoninNeural"   // nebo cs-CZ-VlastaNeural
 *   });
 *
 *   // Push-to-talk: stisknutí začne nahrávat, puštění odešle.
 *   await client.startRecording();
 *   const result = await client.stopAndSend(history);
 *   // result.transcript, result.reply, result.audioBlob
 *   await client.play(result.audioBlob);
 *
 * Historie je pole { role: "user"|"assistant", content: "..." }.
 */
(function (root) {
  "use strict";

  var DEFAULT_VOICE = "cs-CZ-AntoninNeural";
  var ALLOWED_VOICES = ["cs-CZ-AntoninNeural", "cs-CZ-VlastaNeural"];

  function trimSlash(url) {
    return String(url || "").trim().replace(/\/+$/, "");
  }

  function pickRecorderType() {
    if (typeof MediaRecorder === "undefined") return "";
    var candidates = [
      "audio/webm;codecs=opus",
      "audio/webm",
      "audio/mp4",
      "audio/ogg;codecs=opus"
    ];
    for (var i = 0; i < candidates.length; i++) {
      if (MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(candidates[i])) {
        return candidates[i];
      }
    }
    return "";
  }

  function extensionFor(mime) {
    if (!mime) return "webm";
    if (mime.indexOf("mp4") !== -1) return "m4a";
    if (mime.indexOf("ogg") !== -1) return "ogg";
    if (mime.indexOf("mpeg") !== -1 || mime.indexOf("mp3") !== -1) return "mp3";
    return "webm";
  }

  function headers(token) {
    var h = {};
    if (token) h["X-Alfred-Token"] = token;
    return h;
  }

  function parseError(status, payload, fallback) {
    if (payload && payload.error) return payload.error;
    if (status === 401) return "Neplatný klíč nebo token.";
    if (status === 429) return "Server nebo Groq teď odmítá další požadavky. Zkus to za chvíli.";
    return fallback || "Hlasový server vrátil chybu.";
  }

  async function readJsonSafe(response) {
    var text = await response.text();
    if (!text) return {};
    try { return JSON.parse(text); } catch (e) { return { error: text }; }
  }

  async function audioFromPayload(payload) {
    if (!payload || !payload.audio) return null;
    var binary = atob(payload.audio);
    var bytes = new Uint8Array(binary.length);
    for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes], { type: payload.audio_content_type || "audio/mpeg" });
  }

  function create(options) {
    options = options || {};
    var state = {
      serverUrl: trimSlash(options.serverUrl || options.url || ""),
      token: String(options.token || ""),
      voice: ALLOWED_VOICES.indexOf(options.voice) >= 0 ? options.voice : DEFAULT_VOICE,
      recorder: null,
      stream: null,
      chunks: [],
      mimeType: "",
      audioEl: options.audioElement || null
    };

    function configure(next) {
      if (!next) return getConfig();
      if (next.serverUrl != null || next.url != null) state.serverUrl = trimSlash(next.serverUrl || next.url);
      if (next.token != null) state.token = String(next.token || "");
      if (next.voice && ALLOWED_VOICES.indexOf(next.voice) >= 0) state.voice = next.voice;
      return getConfig();
    }

    function getConfig() {
      return { serverUrl: state.serverUrl, token: state.token, voice: state.voice };
    }

    function requireUrl() {
      if (!state.serverUrl) {
        throw new Error("Nejdřív vyplň adresu hlasového serveru, například https://alfred-voice.onrender.com");
      }
    }

    async function health() {
      requireUrl();
      var response = await fetch(state.serverUrl + "/health");
      var payload = await readJsonSafe(response);
      if (!response.ok) throw new Error(parseError(response.status, payload, "Kontrola serveru selhala."));
      return payload;
    }

    async function startRecording() {
      if (state.recorder && state.recorder.state === "recording") return;
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Prohlížeč neumí nahrávat z mikrofonu.");
      }
      if (typeof MediaRecorder === "undefined") {
        throw new Error("MediaRecorder v tomto prohlížeči chybí. Použij Chrome nebo Edge.");
      }
      var stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      var mime = pickRecorderType();
      var recorder = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      state.chunks = [];
      state.mimeType = recorder.mimeType || mime || "audio/webm";
      state.stream = stream;
      state.recorder = recorder;
      recorder.ondataavailable = function (ev) {
        if (ev.data && ev.data.size) state.chunks.push(ev.data);
      };
      recorder.start();
    }

    function isRecording() {
      return !!(state.recorder && state.recorder.state === "recording");
    }

    function stopTracks() {
      if (state.stream) {
        state.stream.getTracks().forEach(function (t) { try { t.stop(); } catch (e) {} });
      }
      state.stream = null;
      state.recorder = null;
    }

    function stopRecording() {
      return new Promise(function (resolve, reject) {
        var recorder = state.recorder;
        if (!recorder || recorder.state === "inactive") {
          stopTracks();
          reject(new Error("Nahrávání neběží."));
          return;
        }
        recorder.onerror = function () {
          stopTracks();
          reject(new Error("Nahrávání selhalo."));
        };
        recorder.onstop = function () {
          var blob = new Blob(state.chunks, { type: state.mimeType || "audio/webm" });
          var mime = state.mimeType;
          stopTracks();
          if (!blob.size) {
            reject(new Error("Nahrávka je prázdná. Zkus mluvit o chvilku déle."));
            return;
          }
          resolve({ blob: blob, mimeType: mime });
        };
        try { recorder.stop(); } catch (e) {
          stopTracks();
          reject(e);
        }
      });
    }

    async function sendVoice(blob, history, mimeType) {
      requireUrl();
      var fd = new FormData();
      var ext = extensionFor(mimeType || blob.type);
      fd.append("audio", blob, "speech." + ext);
      fd.append("voice", state.voice);
      if (history && history.length) fd.append("history", JSON.stringify(history));
      var response = await fetch(state.serverUrl + "/api/voice", {
        method: "POST",
        headers: headers(state.token),
        body: fd
      });
      var payload = await readJsonSafe(response);
      if (!response.ok) throw new Error(parseError(response.status, payload, "Odeslání nahrávky selhalo."));
      payload.audioBlob = await audioFromPayload(payload);
      return payload;
    }

    async function stopAndSend(history) {
      var rec = await stopRecording();
      return sendVoice(rec.blob, history || [], rec.mimeType);
    }

    async function chat(text, history) {
      requireUrl();
      var response = await fetch(state.serverUrl + "/api/chat", {
        method: "POST",
        headers: Object.assign({ "Content-Type": "application/json" }, headers(state.token)),
        body: JSON.stringify({
          text: text,
          history: history || [],
          voice: state.voice
        })
      });
      var payload = await readJsonSafe(response);
      if (!response.ok) throw new Error(parseError(response.status, payload, "Odeslání zprávy selhalo."));
      payload.audioBlob = await audioFromPayload(payload);
      return payload;
    }

    async function tts(text) {
      requireUrl();
      var response = await fetch(state.serverUrl + "/api/tts", {
        method: "POST",
        headers: Object.assign({ "Content-Type": "application/json" }, headers(state.token)),
        body: JSON.stringify({ text: text, voice: state.voice })
      });
      if (!response.ok) {
        var payload = await readJsonSafe(response);
        throw new Error(parseError(response.status, payload, "Čtení hlasem selhalo."));
      }
      return response.blob();
    }

    async function play(blob) {
      if (!blob) return;
      if (!state.audioEl) {
        state.audioEl = document.createElement("audio");
        state.audioEl.setAttribute("preload", "auto");
      }
      if (state.audioEl._alfredUrl) {
        try { URL.revokeObjectURL(state.audioEl._alfredUrl); } catch (e) {}
      }
      var url = URL.createObjectURL(blob);
      state.audioEl._alfredUrl = url;
      state.audioEl.src = url;
      try { await state.audioEl.play(); } catch (e) {
        throw new Error("Prohlížeč zablokoval přehrání zvuku. Klikni na stránku a zkus to znovu.");
      }
    }

    function stopPlayback() {
      if (!state.audioEl) return;
      try { state.audioEl.pause(); } catch (e) {}
      state.audioEl.removeAttribute("src");
    }

    return {
      configure: configure,
      getConfig: getConfig,
      health: health,
      startRecording: startRecording,
      stopRecording: stopRecording,
      stopAndSend: stopAndSend,
      sendVoice: sendVoice,
      isRecording: isRecording,
      chat: chat,
      tts: tts,
      play: play,
      stopPlayback: stopPlayback,
      allowedVoices: ALLOWED_VOICES.slice()
    };
  }

  root.AlfredVoice = { create: create, allowedVoices: ALLOWED_VOICES.slice() };
})(typeof window !== "undefined" ? window : globalThis);
