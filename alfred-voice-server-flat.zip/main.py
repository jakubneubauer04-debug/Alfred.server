"""Alfred voice server: Groq Whisper STT + Groq LLM + Microsoft Edge neural TTS.

Free-tier only. Secrets come from environment variables, never from source.
"""

from __future__ import annotations

import base64
import logging
import os
import re
import secrets
import time
from typing import Any

import edge_tts
import httpx
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from starlette.datastructures import UploadFile as StarletteUploadFile
from starlette.middleware.base import BaseHTTPMiddleware

log = logging.getLogger("alfred-voice")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

GROQ_STT_URL = "https://api.groq.com/openai/v1/audio/transcriptions"
GROQ_CHAT_URL = "https://api.groq.com/openai/v1/chat/completions"
STT_MODEL = "whisper-large-v3-turbo"
LLM_MODEL = "openai/gpt-oss-120b"
LLM_FALLBACK = "openai/gpt-oss-20b"
DEFAULT_VOICE = "cs-CZ-AntoninNeural"
ALLOWED_VOICES = ("cs-CZ-AntoninNeural", "cs-CZ-VlastaNeural")
MAX_AUDIO_BYTES = 8 * 1024 * 1024
MAX_TEXT_CHARS = 2000
MAX_HISTORY = 20
MAX_HISTORY_CHARS = 2000

SYSTEM_PROMPT = (
    "Jsi Alfred, osobní asistent Jakuba. "
    "Odpovídej vždy česky, tykej mu a buď přátelský, věcný a užitečný. "
    "Odpovídej konverzačně, stručně a přirozeně, jako v živém hlasovém rozhovoru. "
    "Používej krátké plynulé věty. Obvykle stačí jedna až tři věty, "
    "pokud tě Jakub výslovně nepožádá o podrobnosti. "
    "Nepoužívej Markdown, seznamy, nadpisy ani emoji. "
    "Nepíš ve stylu článku, který se čte nahlas. "
    "Když něco nevíš, řekni to na rovinu. Nejsou to investiční ani právní rady."
)

app = FastAPI(title="Alfred Voice", version="1.0.0", docs_url=None, redoc_url=None)


class AppError(Exception):
    def __init__(self, message: str, status: int = 400, code: str = "error") -> None:
        self.message = message
        self.status = status
        self.code = code


def _env(name: str) -> str:
    return (os.environ.get(name) or "").strip()


def _allowed_origins() -> list[str] | None:
    raw = _env("ALLOWED_ORIGINS")
    if not raw:
        return None
    return [part.strip() for part in raw.split(",") if part.strip()]


def _origin_allowed(origin: str | None) -> bool:
    allowed = _allowed_origins()
    if allowed is None:
        return True
    if not origin:
        return True
    if origin == "null":
        return True
    return origin in allowed


class CorsMiddleware(BaseHTTPMiddleware):
    """Allow browser calls from a hosted page and from file:// (Origin: null)."""

    async def dispatch(self, request: Request, call_next):
        origin = request.headers.get("origin")
        if request.method == "OPTIONS":
            response: Response = Response(status_code=204)
        else:
            response = await call_next(request)
        if _origin_allowed(origin):
            # Echo the exact origin, including the literal string "null".
            response.headers["Access-Control-Allow-Origin"] = origin if origin else "*"
            response.headers["Vary"] = "Origin"
            response.headers["Access-Control-Allow-Headers"] = (
                "Authorization, Content-Type, X-Alfred-Token"
            )
            response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
            response.headers["Access-Control-Max-Age"] = "86400"
        return response


app.add_middleware(CorsMiddleware)


def error_body(message: str, code: str) -> dict[str, str]:
    return {"error": message, "code": code}


@app.exception_handler(AppError)
async def app_error_handler(_request: Request, exc: AppError) -> JSONResponse:
    return JSONResponse(error_body(exc.message, exc.code), status_code=exc.status)


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    # Keep a stable JSON shape even for bad form/json payloads.
    log.info("validation error: %s", exc.errors())
    _ = request
    return JSONResponse(
        error_body("Požadavek je neúplný nebo má špatný formát.", "bad_request"),
        status_code=400,
    )


@app.exception_handler(Exception)
async def unhandled_handler(_request: Request, exc: Exception) -> JSONResponse:
    log.exception("unhandled error: %s", exc)
    return JSONResponse(
        error_body("Na serveru nastala neočekávaná chyba.", "internal_error"),
        status_code=500,
    )


def require_token(request: Request) -> None:
    expected = _env("ALFRED_TOKEN")
    if not expected:
        return
    got = (request.headers.get("X-Alfred-Token") or "").strip()
    auth = request.headers.get("Authorization") or ""
    if not got and auth.lower().startswith("bearer "):
        got = auth[7:].strip()
    if not got or not secrets.compare_digest(got.encode("utf-8"), expected.encode("utf-8")):
        raise AppError(
            "Chybí nebo je neplatný přístupový token. Do hlavičky X-Alfred-Token vlož hodnotu ALFRED_TOKEN.",
            status=401,
            code="unauthorized",
        )


def require_groq_key() -> str:
    key = _env("GROQ_API_KEY")
    if not key:
        raise AppError(
            "Na serveru není nastavená proměnná GROQ_API_KEY.",
            status=503,
            code="missing_api_key",
        )
    return key


def pick_voice(name: str | None) -> str:
    voice = (name or "").strip() or DEFAULT_VOICE
    if voice not in ALLOWED_VOICES:
        raise AppError(
            "Neznámý hlas. Povolené jsou cs-CZ-AntoninNeural a cs-CZ-VlastaNeural.",
            status=400,
            code="bad_voice",
        )
    return voice


def clean_text(text: str, limit: int = MAX_TEXT_CHARS) -> str:
    cleaned = re.sub(r"\s+", " ", (text or "")).strip()
    if len(cleaned) > limit:
        cleaned = cleaned[:limit].rstrip()
    return cleaned


def parse_history(raw: Any) -> list[dict[str, str]]:
    if raw is None or raw == "":
        return []
    if isinstance(raw, str):
        import json

        try:
            raw = json.loads(raw)
        except Exception as exc:
            raise AppError("Historie konverzace není platný JSON.", 400, "bad_history") from exc
    if not isinstance(raw, list):
        raise AppError("Historie konverzace musí být pole zpráv.", 400, "bad_history")
    out: list[dict[str, str]] = []
    for item in raw[-MAX_HISTORY:]:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role") or "").strip()
        content = clean_text(str(item.get("content") or ""), MAX_HISTORY_CHARS)
        if role in {"user", "assistant"} and content:
            out.append({"role": role, "content": content})
    return out


def extract_chat_text(payload: dict[str, Any]) -> str:
    choices = payload.get("choices") or []
    if not choices:
        return ""
    message = (choices[0] or {}).get("message") or {}
    content = message.get("content")
    if isinstance(content, str) and content.strip():
        return content.strip()
    if isinstance(content, list):
        parts: list[str] = []
        for part in content:
            if isinstance(part, str) and part.strip():
                parts.append(part.strip())
            elif isinstance(part, dict):
                text = part.get("text") or part.get("content") or ""
                if str(text).strip():
                    parts.append(str(text).strip())
        if parts:
            return "\n".join(parts)
    # Some gpt-oss payloads put a short answer next to reasoning.
    for key in ("output_text", "reasoning"):
        alt = message.get(key)
        if isinstance(alt, str) and alt.strip() and key != "reasoning":
            return alt.strip()
    return ""


def classify_groq_error(status: int, body: str) -> AppError:
    lower = (body or "").lower()
    if status in {401, 403} or "invalid api key" in lower or "invalid_api_key" in lower:
        return AppError(
            "Groq API klíč byl odmítnut. Zkontroluj GROQ_API_KEY.",
            status=401,
            code="invalid_api_key",
        )
    if status == 429 or "rate limit" in lower or "too many requests" in lower:
        return AppError(
            "Groq teď odmítá další požadavky (limit bezplatné úrovně). Zkus to za chvíli znovu.",
            status=429,
            code="rate_limited",
        )
    if status in {400, 404} and ("model" in lower or "not found" in lower):
        return AppError(
            "Požadovaný model na Groq teď není dostupný.",
            status=502,
            code="model_unavailable",
        )
    return AppError(
        "Groq API vrátilo chybu. Zkus to prosím znovu.",
        status=502,
        code="groq_error",
    )


async def groq_transcribe(client: httpx.AsyncClient, key: str, data: bytes, filename: str, content_type: str) -> str:
    files = {
        "file": (filename or "speech.webm", data, content_type or "application/octet-stream"),
    }
    form = {
        "model": STT_MODEL,
        "language": "cs",
        "response_format": "json",
    }
    try:
        response = await client.post(
            GROQ_STT_URL,
            headers={"Authorization": f"Bearer {key}"},
            data=form,
            files=files,
            timeout=60.0,
        )
    except httpx.HTTPError as exc:
        raise AppError("Nepodařilo se spojit s Groq (rozpoznávání řeči).", 502, "stt_network") from exc
    if response.status_code >= 400:
        raise classify_groq_error(response.status_code, response.text)
    try:
        payload = response.json()
    except Exception as exc:
        raise AppError("Groq vrátil neočekávanou odpověď při rozpoznávání řeči.", 502, "stt_bad_response") from exc
    text = clean_text(str(payload.get("text") or ""))
    if not text:
        raise AppError("V nahrávce se nepodařilo rozpoznat žádnou řeč.", 422, "empty_transcript")
    return text


async def groq_chat(
    client: httpx.AsyncClient,
    key: str,
    user_text: str,
    history: list[dict[str, str]],
) -> tuple[str, str]:
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.extend(history)
    messages.append({"role": "user", "content": user_text})
    last_error: AppError | None = None
    for model in (LLM_MODEL, LLM_FALLBACK):
        body = {
            "model": model,
            "messages": messages,
            "temperature": 0.7,
            "max_tokens": 400,
        }
        try:
            response = await client.post(
                GROQ_CHAT_URL,
                headers={
                    "Authorization": f"Bearer {key}",
                    "Content-Type": "application/json",
                },
                json=body,
                timeout=60.0,
            )
        except httpx.HTTPError as exc:
            last_error = AppError("Nepodařilo se spojit s Groq (chat).", 502, "llm_network")
            log.warning("chat network error on %s: %s", model, exc)
            continue
        if response.status_code >= 400:
            err = classify_groq_error(response.status_code, response.text)
            # Invalid key or rate limit should not silently fall through to another model.
            if err.code in {"invalid_api_key", "unauthorized", "rate_limited", "missing_api_key"}:
                raise err
            last_error = err
            log.warning("chat error on %s: %s %s", model, response.status_code, response.text[:500])
            continue
        try:
            payload = response.json()
        except Exception:
            last_error = AppError("Groq vrátil neočekávanou odpověď chatu.", 502, "llm_bad_response")
            continue
        text = clean_text(extract_chat_text(payload), MAX_TEXT_CHARS)
        if text:
            return text, model
        last_error = AppError("Model vrátil prázdnou odpověď.", 502, "empty_reply")
    raise last_error or AppError("Chat se nepovedl.", 502, "llm_error")


async def synthesize(text: str, voice: str) -> bytes:
    communicate = edge_tts.Communicate(text, voice)
    chunks: list[bytes] = []
    try:
        async for item in communicate.stream():
            if item["type"] == "audio":
                chunks.append(item["data"])
    except Exception as exc:
        log.exception("edge-tts failed")
        raise AppError(
            "Hlasový výstup teď není dostupný (edge-tts / hlasy Microsoft Edge). Zkus to znovu za chvíli.",
            status=502,
            code="tts_error",
        ) from exc
    audio = b"".join(chunks)
    if not audio:
        raise AppError("Hlasový výstup vrátil prázdný soubor.", 502, "tts_empty")
    return audio


def json_audio_payload(reply: str, audio: bytes, voice: str, transcript: str | None, model: str | None) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "reply": reply,
        "audio": base64.b64encode(audio).decode("ascii"),
        "audio_content_type": "audio/mpeg",
        "voice": voice,
    }
    if transcript is not None:
        payload["transcript"] = transcript
    if model:
        payload["model"] = model
    return payload


async def _read_json(request: Request) -> dict[str, Any]:
    try:
        data = await request.json()
    except Exception as exc:
        raise AppError("Tělo požadavku není platný JSON.", 400, "bad_request") from exc
    if not isinstance(data, dict):
        raise AppError("Tělo požadavku musí být JSON objekt.", 400, "bad_request")
    return data


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "ok": True,
        "service": "alfred-voice",
        "stt": STT_MODEL,
        "llm": LLM_MODEL,
        "llm_fallback": LLM_FALLBACK,
        "tts": "edge-tts",
        "voices": list(ALLOWED_VOICES),
        "groq_key_configured": bool(_env("GROQ_API_KEY")),
        "token_required": bool(_env("ALFRED_TOKEN")),
    }


@app.post("/api/tts")
async def api_tts(request: Request) -> Response:
    require_token(request)
    voice = DEFAULT_VOICE
    text = ""
    content_type = (request.headers.get("content-type") or "").lower()
    if "application/json" in content_type:
        data = await _read_json(request)
        text = str(data.get("text") or "")
        voice = pick_voice(data.get("voice"))
    else:
        form = await request.form()
        text = str(form.get("text") or "")
        voice = pick_voice(str(form.get("voice") or "") or None)
    text = clean_text(text)
    if not text:
        raise AppError("Chybí text k přečtení.", 400, "missing_text")
    t0 = time.time()
    audio = await synthesize(text, voice)
    log.info("tts voice=%s bytes=%s in %.2fs", voice, len(audio), time.time() - t0)
    return Response(content=audio, media_type="audio/mpeg")


@app.post("/api/chat")
async def api_chat(request: Request) -> JSONResponse:
    require_token(request)
    key = require_groq_key()
    data = await _read_json(request)
    text = clean_text(str(data.get("text") or data.get("message") or ""))
    if not text:
        raise AppError("Chybí text zprávy.", 400, "missing_text")
    history = parse_history(data.get("history") or data.get("messages"))
    voice = pick_voice(data.get("voice"))
    async with httpx.AsyncClient() as client:
        reply, model = await groq_chat(client, key, text, history)
    audio = await synthesize(reply, voice)
    return JSONResponse(json_audio_payload(reply, audio, voice, transcript=None, model=model))


@app.post("/api/voice")
async def api_voice(request: Request) -> JSONResponse:
    """Accept multipart (field 'audio' or 'file') or JSON with base64 'audio'."""
    require_token(request)
    key = require_groq_key()
    history_raw: Any = None
    voice_name: str | None = None
    raw = b""
    filename = "speech.webm"
    content_type = "audio/webm"
    ctype = (request.headers.get("content-type") or "").lower()
    if "application/json" in ctype:
        data = await _read_json(request)
        b64 = data.get("audio") or data.get("audio_base64")
        if not b64:
            raise AppError("Chybí nahrávka (pole audio).", 400, "missing_audio")
        try:
            raw = base64.b64decode(str(b64), validate=False)
        except Exception as exc:
            raise AppError("Nahrávka není platný base64.", 400, "bad_audio") from exc
        filename = str(data.get("filename") or "speech.webm")
        content_type = str(data.get("audio_content_type") or "audio/mpeg")
        history_raw = data.get("history") or data.get("messages")
        voice_name = data.get("voice")
    elif "multipart/form-data" in ctype:
        form = await request.form()
        upload = form.get("audio") or form.get("file")
        # request.form() yields Starlette's UploadFile, not FastAPI's subclass.
        if not isinstance(upload, StarletteUploadFile):
            raise AppError(
                "Chybí nahrávka. Pošli soubor v poli audio (multipart) nebo base64 v JSON.",
                400,
                "missing_audio",
            )
        raw = await upload.read()
        filename = upload.filename or filename
        content_type = upload.content_type or content_type
        history_raw = form.get("history") or form.get("messages")
        voice_field = form.get("voice")
        voice_name = str(voice_field) if voice_field else None
    else:
        raise AppError(
            "Chybí nahrávka. Pošli soubor v poli audio (multipart) nebo base64 v JSON.",
            400,
            "missing_audio",
        )
    if not raw:
        raise AppError("Nahrávka je prázdná.", 400, "empty_audio")
    if len(raw) > MAX_AUDIO_BYTES:
        raise AppError("Nahrávka je příliš velká (maximum je 8 MB).", 413, "audio_too_large")
    chosen_voice = pick_voice(voice_name)
    chosen_history = parse_history(history_raw)
    async with httpx.AsyncClient() as client:
        transcript = await groq_transcribe(client, key, raw, filename, content_type)
        reply, model = await groq_chat(client, key, transcript, chosen_history)
    spoken = await synthesize(reply, chosen_voice)
    return JSONResponse(json_audio_payload(reply, spoken, chosen_voice, transcript, model))
